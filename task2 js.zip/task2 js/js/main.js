
function randomText() {
    var quotes = [
        "Be yourself; everyone else is already taken.",
        "A room without books is like a body without a soul."
    ];
    var authors = [
        "Oscar Wilde",
        "Frank Zappa"
    ];

    var num = Math.floor(Math.random() * quotes.length);

    document.getElementById("randomQuote").innerText = quotes[num];
    document.getElementById("quoteAuthor").innerText = "- " + authors[num];
}


